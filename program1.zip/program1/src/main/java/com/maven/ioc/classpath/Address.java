package com.maven.ioc.classpath;

public class Address {
    private String city="Bangalore";
    private String street="Ananthangr";
    public void getDetails(){
        System.out.println("City"+city);
        System.out.println("Street"+street);
    }


}
