package com.maven.ioc.filesystem;

public class Organisation {
    private String organisationName="Upgrad";
    private int establishedYear=2000;
    private String ceo="John";
    public void getDetails(){
        System.out.println("OrganisationNmae"+organisationName);
        System.out.println("EstablishedYear"+establishedYear);
        System.out.println("CEO"+ceo);
    }
}
