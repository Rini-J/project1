package com.maven.ioc;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class TestMain {
    public static void main(String[] args){
       XmlBeanFactory factory=new XmlBeanFactory(new ClassPathResource("beanfactory.xml"));

        Student s1=factory.getBean("student",Student.class);
        s1.getDetails();
        Employee e1=factory.getBean("employee",Employee.class);
        e1.getDetails();

    }
}
