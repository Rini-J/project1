package com.maven.ioc.classpath;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestMain {
    public static void main(String[] args) {
        ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("classpath.xml");
        Address a1=context.getBean("address",Address.class);
        a1.getDetails();
    }
}
