package com.maven.ioc;

public class Employee {
    private int employeeID;
    private String employeeName;
    public void getDetails(){
        System.out.println("EmployeeId"+employeeID);
        System.out.println("EmployeeName"+employeeName);
    }

}
