package com.maven.ioc;

public class Student {
    private int studentId;
    private String studentName;
    public void getDetails(){
        System.out.println("StudentId"+studentId);
        System.out.println("StudentName:"+studentName);
    }
}
