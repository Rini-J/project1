package com.maven.ioc.filesystem;

import org.springframework.context.support.FileSystemXmlApplicationContext;

public class TestMain {
    public static void main(String[] args) {
        //FileS/home/rini/MVC/helloworld/program1ystemXmlApplicationContext context=new FileSystemXmlApplicationContext("/home/rini/MVC/helloworld/program1/src/main/resources/filesystem.xml");
      FileSystemXmlApplicationContext context=new FileSystemXmlApplicationContext("./src/main/resources/filesystem.xml");
        Organisation o1=(Organisation)context.getBean("organisation");
        o1.getDetails();

    }
}
